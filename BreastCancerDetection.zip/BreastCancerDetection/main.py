# Breast cancer detection bot

import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import joblib

# preparing the data
cancer_data = pd.read_csv('Breast_cancer_data.csv')
x = cancer_data.drop(columns=['diagnosis'])
y = cancer_data['diagnosis']

# creating training/test data
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.8)

# creating the model
# model = DecisionTreeClassifier()

# Training the model
# model.fit(x_train, y_train)

# load the model
model = joblib.load('breast-cancer-detection.joblib')

# making and displaying the prediction
print("1 = Positive Diagnosis \n0 = Negative Diagnosis")

prediction = model.predict(x_test)
print(prediction)

# accuracy testing

score = accuracy_score(y_test, prediction)
print(score)



