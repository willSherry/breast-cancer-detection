from sklearn.model_selection import train_test_split
import joblib

while(True):

    try:
        user_radius = float(input("Mean Radius: "))
        user_texture = float(input("Mean Texture: "))
        user_perimeter = float(input("Mean Perimeter: "))
        user_area = float(input("Mean Area: "))
        user_smoothness = float(input("Mean Smoothness: "))
    except:
        print("Please only input decimal numbers.")

user_data = [user_radius, user_texture, user_perimeter, user_area, user_smoothness]

model = joblib.load('breast-cancer-detection.joblib')
model.predict()